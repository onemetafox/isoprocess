<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends MY_Controller
{
	public function login() {
		$this->mHeader['title'] = 'Login';
		$this->mHeader['menu_title'] = 'login';

		$param = $this->input->post('login');
		if ($param) {
			$validation = [
				[
					'field' => 'login[username]',
					'label' => 'Username',
					'rules' => 'required'
				], [
					'field' => 'login[password]',
					'label' => 'Password',
					'rules' => 'required'
				]
			];
			$this->form_validation->set_rules($validation);

			if (!$this->form_validation->run())
				$this->render('login');
			else {
				$type = $this->input->post('usertype');
				$param['password'] = md5($param['password']);
				$username = $param['username'];
				$password = $param['password'];
				if($type == "admin"){
					$user = $this->Auth_model->login($param, $type);
					if($user){
						$user->type = $type;
						$this->session->set_userdata('user', $user);
						$this->session->set_userdata([
								'admin_id' => $user->id,
								'username' => $user->username
						]);
					}
				}
				else if($type == 'consultant' || $type == "executive"){
					$user = $this->Auth_model->login($param, $type);
					if($user){
						$user->type = $type;
						$this->session->set_userdata('user', $user);
						$this->session->set_userdata([
								'consultant_id' => $user->consultant_id,
								'username' => $user->username,
								'user_type' => $user->type,
								'com_status' => $user->status
						]);
					}
				} else{
					$user = $this->Auth_model->employee_login($username, $password, $type);
					if($user){
						$user->type = $type;
						$this->session->set_userdata('user', $user);
						$this->session->set_userdata([
								'employee_id' => $user->employee_id,
								'username' => $user->username,
								'consultant_id' => $user->consultant_id,
								'user_type' => $user->type,
								'com_status' => $user->status
						]);
					}
				}

				if($user){
					$this->redirect('welcome/dashboard');
				}
				else {
					$this->session->set_flashdata('flash', [
							'msg' => 'Invalid credentials'
					]);
					$this->render('login');
				}
			}
		} else
			$this->render('login');
	}

	public function register() {
		$this->mHeader['title'] = 'Register';
		$this->mHeader['menu_title'] = 'register';

		$param = $this->input->post('register');
		$email = $param['email'];
		$username = $param['username'];

		if ($param) {
			$validation = [
				[
					'field' => 'register[consultant_name]',
					'label' => 'Company Name',
					'rules' => 'required'
				], [
					'field' => 'register[username]',
					'label' => 'Username',
					'rules' => 'required|is_unique[consultant.username]'
				], [
					'field' => 'register[email]',
					'label' => 'Email',
					'rules' => 'required|valid_email|is_unique[consultant.email]'
				], [
					'field' => 'register[password]',
					'label' => 'Password',
					'rules' => 'required'
				], [
					'field' => 'register[repassword]',
					'label' => 'Password',
					'rules' => 'required'
				], [
					'field' => 'register[repassword]',
					'label' => 'Password Confirmation',
					'rules' => 'required|matches[register[password]]'
				]
			];
			$this->form_validation->set_rules($validation);

			if (!$this->form_validation->run() || stristr($email, "<script>") != FALSE || stristr($username, "<script>") != FALSE)
				$this->render('Register/register');
			else {
				// $param['password'] = md5($param['password']);
				$param['created_at'] = date('Y-m-d');
				$param['user_type'] = 'consultant';
				$param['logo'] = 1;
				unset($param['repassword']);

				$param['password'] = md5($param['password']);

				$consultant_id = $this->Auth_model->consultant_register($param);
				if ($consultant_id > 0) {
					//----------------------------------------------send email----------------------------------------------
					$email_temp = $this->getEmailTemp('User sign up for subscription');
					$email_temp['message'] = str_replace("{USERNAME}", $username, $email_temp['message']);
					$email_temp['message'] = str_replace("{COURSE_NAME}", 'isoimplementationsoftware.com', $email_temp['message']);
					$email_temp['message'] = str_replace("{LOGO}", "<img src='cid:logo'>", $email_temp['message']);
					$this->sendemail($email, 'User sign up for subscription', $email_temp['message'], $email_temp['subject']);
					//---------------------------------------------------------------------------------------------------------
					$this->session->set_userdata([
						'username' => $param['username'],
						'consultant_id' => $consultant_id
					]);
					$this->redirect('auth/reg_pay_plans');
				}
			}
		} else
			$this->render('Register/register');
	}

	public function reg_pay_plans() {
		$this->mHeader['title'] = 'Register Pay Plans';
		$this->mHeader['menu_title'] = 'register_pay_plans';

		$this->mContent['plans'] = $this->Plan_model->find([
			'is_trial' => 0
		], ['no_of_user' => 'asc']);
		$this->mContent['trial_plan'] = $this->Plan_model->one([
			'is_trial' => 1
		]);

		$this->render('Register/register_payment_plans');
	}

	public function add_purchase() {
		$plan_id = $this->input->post('plan_id');

		if ($plan_id == '0')
			$this->redirect('auth/reg_pay_plans');
		else {
			if ($plan_id == '1')
				$this->trial();
			else {
				$consultant_id = $this->session->userdata('consultant_id');
				$result = $this->Consultant_model->update(['consultant_id' => $consultant_id], ['plan_id' => $plan_id]);

				if ($result)
					$this->redirect('auth/reg_pay_plans');
				else
					$this->redirect('auth/term_condition');
			}
		}
	}

	public function trial() {
		$consultant_id = $this->session->userdata('consultant_id');
		if (!$consultant_id)
			$this->redirect('auth/reg_pay_plans');
		else {
			$param = [
				'plan_type' => 'trial',
				'plan_id' => 1,
				'expired' => date('Y-m-d', strtotime(date('Y-m-d') . ' + 14 days')),
				'status' => 1
			];

			$this->Consultant_model->update(['consultant_id' => $consultant_id], $param);

			$this->session->set_userdata(['com_status' => 1]);

			$this->redirect('welcome/dashboard');
		}
	}

	public function term_condition() {
		$this->mHeader['title'] = 'Term Condition';
		$this->mHeader['menu_title'] = 'term_condition';

		$this->render('Register/term_condition');
	}

	public function next_process_done() {
		$checked = $this->input->post('checkeds');
		if ($checked == 'on')
			$this->redirect('auth/payment');
		else
			$this->redirect('auth/reg_pay_plans');
	}

	public function payment() {
		$consultant_id = $this->session->userdata('consultant_id');
		if (isset($consultant_id)) {
			$this->mHeader['title'] = 'Payment';
			$this->mHeader['menu_title'] = 'payment';

			$this->mContent['company'] = $this->Consultant_model->one(['consultant_id' => $consultant_id]);
			$this->mContent['plan'] = $this->Plan_model->one(['plan_id' => $this->mContent['company']->plan_id]);

			$this->render('Register/reg_payment');
		} else
			$this->redirect('auth/reg_pay_plans');
	}

	public function logout() {
		$this->session->sess_destroy();
		$this->redirect('welcome');
	}

	public function next_process2() {
		$data['title'] = 'Next';
		$query         = $this->db->get('plan');
		$data['plan']  = $query->result();
		$this->load->view('process_two', $data);
	}

	public function payment_option() {

		$date             = date('Y-m-d');
		$total_amount     = $this->input->post('total_amount');
		$company_id       = $this->input->post('consultant_id');
		$plan_id          = $this->input->post('plan_id');

		require_once('./config.php');
		$token = $_POST['stripeToken'];
		$email = $_POST['stripeEmail'];

		$customer = \Stripe\Customer::create(array(
			'email' => $email,
			'source' => $token
		));

		$charge = \Stripe\Charge::create(array(
			'customer' => $customer->id,
			'amount' => $total_amount * 100,
			'currency' => 'usd'
		));

		$data = array(
			'total_amount' => $total_amount,
			'consultant_id' => $company_id,
			'payment_status' => 'paid',
			'token' => $customer->created,
			'transaction_id' => $customer->id,
			'updated_at' => date('Y-m-d', strtotime($date)),
			'purchase_plan_id' => $plan_id
		);

		$paid = $this->db->insert('payment', $data);
		if ($paid) {

			$expired = date('Y-m-d', strtotime($date . ' + 365 days'));

			$data2 = array(
				'status' => 1,
				'plan_type' => 'real',
				'expired' => $expired,
				'plan_id' => $plan_id
			);
			$this->db->where('consultant_id', $company_id);
			$paid1 = $this->db->update('consultant', $data2);

			$datan = array(
				'com_status' => 1,
				'user_type' => 'consultant',
			);
			$this->session->set_userdata($datan);

			redirect('Welcome/consultantdashboard');

		} else {
			redirect('Auth/reg_pay_plans');
		}
	}


	public function get_purchase($ppi = NULL) {
		$this->db->where('purchase_plan_id', $ppi);
		$query = $this->db->get('purchase_plan');
		return $query->row();
	}


	public function update_process() {
		$this->mHeader['title'] = 'Upgrade';
		$this->mHeader['menu_title'] = $this->mHeader['title'];

		$consultant_id = $this->session->userdata('consultant_id');
		$consultant = $this->Consultant_model->one(['consultant_id' => $consultant_id]);
		$chk = $this->Plan_model->one(['plan_id' => $consultant->plan_id]);

		$where = ['is_trial' => 0];
		if ($consultant->plan_id != '1')
			array_merge($where, ['no_of_user > ' => $chk->no_of_user]);

		$this->mContent['plans'] = $this->Plan_model->find($where, ['no_of_user' => 'asc']);
		$this->mContent['upgrade'] = 0;

		$this->render('consultant/update_process');
	}

	public function check_update_process($consultant_id)
	{

		$data = $this->db->query("select * from `consultant` where `consultant_id`='$consultant_id' ")->row()->plan_id;

		if ($data) {
			$data1 = $this->db->query("select * from `plan` where `plan_id`='$data'")->row();
			return $data1;
		}
	}


	public function forgot_pass()
	{

		$this->load->model('Authmodel');
		$this->load->library('form_validation');

		$data['title'] = 'Next';
		$this->load->view('forgot_pass', $data);
	}

	public function forgot_pass_send_link()
	{

		$this->load->model('Authmodel');
		$this->load->library('form_validation');

		$data['title'] = 'Next';
		$email         = $this->input->post('email');

		if ($email != '') {
			$very1 = $this->Authmodel->admin_email($email);
			$very2 = $this->Authmodel->employee_email($email);
			$very3 = $this->Authmodel->consultant_email($email);
			if ($very1 || $very2 || $very3) {
				$pass = rand(100000, 999999);
				$dd   = array(
					'password' => $pass
				);
				$this->load->library('email');
				if ($very1) {
					$this->db->where('email', $email);
					$query = $this->db->update('admin', $dd);
				}
				if ($very2) {
					$this->db->where('employee_email', $email);
					$query = $this->db->update('employees', $dd);
				}
				if ($very3) {
					$this->db->where('email', $email);
					$query = $this->db->update('consultant', $dd);
				}
				$this->load->library('email');

				$email   = $email;
				$subject = 'Forgot Password';

				$htmlContent = 'Dear User, Your new Password is ' . $pass;


				$this->email->from('admin@rrgpos.com', 'New Password');
				$this->email->to($email);
				$this->email->subject($subject);
				$this->email->message($htmlContent);
				if ($this->email->send()) {
					$this->load->view('forgot_pass_send_link', $data);
				} else {
					$this->session->set_flashdata('message', 'Invalid Email Address');
					redirect('Auth/forgot_pass');
				}

			} else {
				$this->session->set_flashdata('message', 'Invalid Email Address');
				redirect('Auth/forgot_pass');
			}
			$this->load->view('forgot_pass_send_link', $data);
		} else {
			redirect('Welcome');
		}
	}

	public function upgrade_plan()
	{
		$this->load->model('Companymodel');
		$plan_id    = $this->input->post('plan_id');
		$consultant_id = $this->session->userdata('consultant_id');

		if(!isset($consultant_id)){
			$this->session->sess_destroy();
			redirect('Welcome');
		}


		if ($plan_id == 0 || $plan_id == '0') {
			redirect('Auth/update_process');
		} else {
			$data = array();
			$data['title'] = 'agreement';
			$data['plan_id'] = $plan_id;
			//$result = $this->consultantmodel->update_consultant($data, $consultant_id);
			//redirect('Auth/term_condition');
			$this->load->view('upgrade_term_condition', $data);
		}

	}


	public function upgrade_process_done()
	{
		$checked = $this->input->post('checkeds');
		$plan_id = $this->input->post('plan_id');

		if ($checked != '') {
			redirect('Auth/upgrade_payment/'.$plan_id);
		} else {
			redirect('Auth/upgrade_plan');
		}
	}


	public function upgrade_payment($plan_id=0)
	{
		$consultant_id = $this->session->userdata('consultant_id');


		if (isset($consultant_id)) {

			$this->load->model('Companymodel');
			$this->load->model('Planmodel');

			$consultant = $this->Companymodel->get_company($consultant_id);
			$plan = $this->Planmodel->get_plan($plan_id);

			$data['consultant'] = $consultant;
			$data['plan'] = $plan;


			$data['title'] = 'Payment';
			$this->load->view('upgrade_reg_payment', $data);

		} else {
			redirect('Auth/reg_pay_plans');
		}

	}

	public function terms(){

		$data['menu_title'] = 'payment';
		$this->load->view('terms', $data);
	}

}
